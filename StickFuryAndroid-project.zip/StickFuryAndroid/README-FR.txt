STICK FURY — PROJET ANDROID HORS LIGNE

Ce dossier contient un projet Android Studio qui embarque le jeu HTML localement.
L'application n'a pas besoin de connexion Internet pour charger le jeu.
Le mode paysage et le plein écran sont activés. Les commandes tactiles et les boutons
Échap (flèche) et Espace du fichier HTML sont conservés.

IMPORTANT
Ce paquet est le PROJET SOURCE, pas un APK compilé. L'environnement où il a été préparé
ne contient pas Android SDK/Gradle et n'a pas d'accès réseau pour télécharger les outils ;
je ne peux donc pas prétendre qu'un APK a été compilé/testé ici.

GÉNÉRER L'APK
1. Installer Android Studio sur un ordinateur.
2. Décompresser StickFuryAndroid.zip.
3. Android Studio > Open, puis sélectionner le dossier StickFuryAndroid.
4. Attendre la synchronisation Gradle et installer les composants SDK proposés.
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK de test sera créé dans app/build/outputs/apk/debug/app-debug.apk.
7. Copier ce fichier sur le téléphone Android et l'ouvrir pour l'installer.

Si Android Studio demande une version de SDK, installer Android SDK Platform 35.
